package edu.eci.escuelaing.covidtool.covidtool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidtoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
